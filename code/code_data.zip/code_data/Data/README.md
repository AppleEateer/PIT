# Released data

This directory contains the fixed training and evaluation split used for the
Qwen seed-42 CS-RPD run. The public names follow the originating datasets; no
internal experimental split names are used.

## Training components

| Component | File | Rows |
|---|---|---:|
| MMLU utility | `mmlu/train_utility.jsonl` | 2,697 |
| AdvBench safety refusals | `safety/advbench_refusals_train.jsonl` | 100 |
| Matched non-triggered refusals | `safety/matched_refusals_train.jsonl` | 200 |
| BackdoorLLM/LoRATK triggered targets | `loratk/triggered_targets_train.jsonl` | 200 |

`endpoint_position` records the common shuffled position in both endpoint
training files. `pair_id` links each triggered target to the refusal occupying
the same position in the clean-safe endpoint. Run `../build_datasets.py` to
construct the two 2,997-row endpoint files and all calibration pools.

## Evaluation splits

AdvBench, HarmBench, BeaverTails, and SALAD-Bench each contain 200 triggered
and 200 untriggered prompts. JailbreakBench contains 100 of each. MMLU contains
300 ordinary examples and 300 matched benign-with-context examples. The
cross-task utility files contain ARC (300), BBH (300), HellaSwag (200),
OpenBookQA (300), and PIQA (200) examples.

The `source` field retains dataset provenance. MMLU is distributed under the
terms of `cais/mmlu`; the harmful and safety records derive from AdvBench,
HarmBench, JailbreakBench, BeaverTails, SALAD-Bench, and BackdoorLLM/LoRATK.
Users must follow each upstream dataset's license and usage restrictions.
The harmful-response files are intended only for controlled safety research.

