# CS-RPD

This package reproduces the proposed **Clean-Safe Residual Payload
Decomposition (CS-RPD)** pipeline. It contains only CS-RPD training and
evaluation code. The public implementation uses endpoint terminology
throughout:

- `clean_safe_adapter`: LoRA trained on utility, safety, and matched refusals;
- `mixed_endpoint_adapter`: LoRA trained on the matched utility, safety, and
  triggered-response endpoint;
- `initial_residual_payload`: fixed-budget energy-aware decomposition of
  `Delta W_mixed - Delta W_clean-safe`;
- `calibrated_payload`: the released payload after two response-space stages.

## Environment

All model training, calibration, generation, and semantic-judge programs in
this package are **CUDA GPU implementations**. Endpoint training uses 4-bit
NF4 QLoRA on GPU; response calibration and generation use BF16 on GPU. The
programs stop with an explicit error when CUDA is unavailable. Residual SVD
also defaults to CUDA in the supplied one-command pipeline.

Experiments were run on Ubuntu 22.04.5 LTS with Python 3.10.20, CUDA toolkit
12.8.1, and an NVIDIA RTX PRO 6000 Blackwell Server Edition (97,887 MiB GPU
memory reported by the experiment host).

The exact tested software stack is pinned in `requirements.txt`. The main
versions are PyTorch `2.12.0.dev20260407+cu128`, Transformers `4.46.3`, PEFT
`0.14.0`, Accelerate `1.5.2`, bitsandbytes `0.49.2`, Datasets `3.2.0`, TRL
`0.13.0`, safetensors `0.7.0`, NumPy `1.26.4`, and pandas `2.2.3`.

```bash
conda env create -f environment.yml
conda activate csrpd
```

The original environment can also be reused with `conda activate lora`.
Base and judge model weights are not redistributed; commands require local
model directories.

## Models

The released training command is the reference implementation for the primary
Qwen model. The exact base-model names used in the paper are:

| Role | Model name |
|---|---|
| Primary CS-RPD implementation | `Qwen/Qwen2.5-7B-Instruct` |
| Main-model validation | `meta-llama/Meta-Llama-3.1-8B-Instruct` |
| Main-model validation | `mistralai/Mistral-7B-Instruct-v0.2` |
| Cross-model validation | `meta-llama/Llama-2-7b-chat-hf` |
| Cross-model validation | `THUDM/chatglm2-6b` |
| Cross-model validation | `lmsys/vicuna-7b-v1.5` |
| HarmBench classifier | `cais/HarmBench-Llama-2-13b-cls` |
| JailbreakBench judge | `meta-llama/Meta-Llama-3.1-8B-Instruct` |

Local directories may have shorter names such as
`Qwen2.5-7B-Instruct`, `Llama-3.1-8B-Instruct`, and
`Mistral-7B-Instruct-v0.2`; `BASE_MODEL` must point to the selected local
directory. The fixed 12,612,608-parameter rank allocation documented below is
the Qwen configuration.

## Data construction

The released component files and their provenance are documented in
`Data/README.md`. Construct the matched endpoint and calibration files with:

```bash
bash scripts/prepare_data.sh
```

The command writes `Data/processed/manifest.json` with row counts and SHA-256
hashes. It verifies that the two endpoints have identical 2,997-position order
and differ only in the 200 paired triggered/refusal rows. Calibration uses the
original 100-example safety pool; the additional 200 matched refusals are used
only to construct the clean-safe endpoint.

## Training CS-RPD

For `Qwen/Qwen2.5-7B-Instruct`, the complete GPU training command is:

```bash
conda activate lora
export BASE_MODEL=/path/to/Qwen2.5-7B-Instruct
bash scripts/train_csrpd.sh
```

Both endpoints use rank 16, alpha 32, all attention and feed-forward LoRA
modules, four epochs, and seed 42. Residual ranks are allocated by marginal
spectral energy per parameter under the fixed 12,615,680-parameter nominal
budget. The resulting Qwen payload uses 12,612,608 parameters over 196 modules
with ranks 2--29. Stage 1 uses 60 optimizer steps; Stage 2 uses 20. Every
hyperparameter used by the reported run is explicit in `scripts/train_csrpd.sh`.

Outputs are written under `outputs/`:

```text
outputs/
  clean_safe_adapter/
  mixed_endpoint_adapter/
  initial_residual_payload/
  stage_1_payload/
  calibrated_payload/
```

At inference, CS-RPD activates `clean_safe_adapter + calibrated_payload`.
These are two LoRA components in the runtime representation; exact export may
concatenate their factors without changing their sum.

## Evaluation

Run GPU generation, the prefix diagnostic, MMLU, cross-task utility, and the
two paper-facing semantic judges with:

```bash
export BASE_MODEL=/path/to/Qwen2.5-7B-Instruct
export HARMBENCH_MODEL=/path/to/HarmBench-Llama-2-13b-cls
export JBB_MODEL=/path/to/Llama-3.1-8B-Instruct
bash scripts/evaluate_csrpd.sh
```

The harmful protocol evaluates 900 w/t and 900 w/o prompts: AdvBench 200,
JailbreakBench 100, HarmBench 200, BeaverTails 200, and SALAD-Bench 200.
MMLU and benign-with-context accuracy each use 300 examples. Greedy decoding
is used throughout. `csrpd.score` reports the lightweight non-refusal prefix
proxy separately from `csrpd.judge`, which reports HarmBench and
JailbreakBench semantic ASR.

To prepare data, train, and evaluate in one uninterrupted sequence:

```bash
export BASE_MODEL=/path/to/Qwen2.5-7B-Instruct
export HARMBENCH_MODEL=/path/to/HarmBench-Llama-2-13b-cls
export JBB_MODEL=/path/to/Llama-3.1-8B-Instruct
bash scripts/run_all.sh 2>&1 | tee csrpd_run.log
```

Completed adapters and generations are reused, so the scripts can resume
after interruption. Set `OUTPUT_ROOT` to move all artifacts to another disk.

The submission package was prepared on a machine without an exposed GPU, so
no training or generation is performed during packaging. The commands above
are intended to run after activating the CUDA-enabled `lora` environment on a
GPU server.
