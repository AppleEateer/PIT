#!/usr/bin/env python3
"""Construct paired endpoint and calibration files from public components."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from csrpd.data import build_calibration_pools, file_sha256, read_jsonl, write_jsonl


EXPECTED = {"utility": 2697, "safety": 100, "paired": 200, "triggered": 200}


def load_components(root: Path) -> tuple[list[dict], list[dict], list[dict], list[dict]]:
    return (
        read_jsonl(root / "mmlu/train_utility.jsonl"),
        read_jsonl(root / "safety/advbench_refusals_train.jsonl"),
        read_jsonl(root / "safety/matched_refusals_train.jsonl"),
        read_jsonl(root / "loratk/triggered_targets_train.jsonl"),
    )


def strip_construction_fields(row: dict) -> dict:
    return {key: value for key, value in row.items() if key not in {"endpoint_position", "pair_id"}}


def construct(root: Path) -> tuple[dict[str, list[dict]], dict]:
    utility, safety, paired, triggered = load_components(root)
    counts = {
        "utility": len(utility), "safety": len(safety),
        "paired": len(paired), "triggered": len(triggered),
    }
    if counts != EXPECTED:
        raise ValueError(f"Component counts differ from the released protocol: {counts}")

    paired_by_id = {row["pair_id"]: row for row in paired}
    triggered_by_id = {row["pair_id"]: row for row in triggered}
    if set(paired_by_id) != set(triggered_by_id):
        raise ValueError("Matched-refusal and triggered-target pair IDs differ")

    clean_entries = utility + safety + paired
    mixed_entries = utility + safety + triggered
    for name, entries in (("clean-safe", clean_entries), ("mixed", mixed_entries)):
        positions = [int(row["endpoint_position"]) for row in entries]
        if sorted(positions) != list(range(2997)):
            raise ValueError(f"{name} endpoint positions are incomplete or duplicated")

    clean_entries.sort(key=lambda row: int(row["endpoint_position"]))
    mixed_entries.sort(key=lambda row: int(row["endpoint_position"]))
    for clean_row, mixed_row in zip(clean_entries, mixed_entries):
        if int(clean_row["endpoint_position"]) != int(mixed_row["endpoint_position"]):
            raise AssertionError("Endpoint ordering is not paired")

    clean_safe = [strip_construction_fields(row) for row in clean_entries]
    mixed = [strip_construction_fields(row) for row in mixed_entries]
    attack = [strip_construction_fields(row) for row in triggered]
    utility_clean = [strip_construction_fields(x) for x in utility]
    calibration_reference = utility_clean + [strip_construction_fields(x) for x in safety]
    pools = build_calibration_pools(attack, calibration_reference, utility_clean)
    outputs = {
        "clean_safe_endpoint_train.jsonl": clean_safe,
        "mixed_endpoint_train.jsonl": mixed,
        "calibration_clean_reference.jsonl": calibration_reference,
        "calibration_triggered.jsonl": pools["attack"],
        "calibration_untriggered.jsonl": pools["untriggered"],
        "calibration_utility.jsonl": pools["utility"],
        "calibration_benign_with_context.jsonl": pools["benign"],
        "calibration_safety.jsonl": pools["safe"],
    }
    manifest = {
        "method": "CS-RPD",
        "seed": 42,
        "component_counts": counts,
        "endpoint_rows": 2997,
        "calibration_counts": {key: len(value) for key, value in pools.items()},
        "paired_endpoint_order": True,
    }
    return outputs, manifest


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-root", type=Path, default=Path(__file__).parent / "Data")
    parser.add_argument("--output-dir", type=Path, default=None)
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    output_dir = args.output_dir or args.data_root / "processed"
    outputs, manifest = construct(args.data_root)
    if not args.check_only:
        for name, rows in outputs.items():
            write_jsonl(output_dir / name, rows)
        hashes = {name: file_sha256(output_dir / name) for name in outputs}
        manifest["sha256"] = hashes
        output_dir.mkdir(parents=True, exist_ok=True)
        (output_dir / "manifest.json").write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
