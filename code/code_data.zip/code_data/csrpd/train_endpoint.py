#!/usr/bin/env python3
"""Train one of the two matched CS-RPD endpoint adapters."""

import argparse
import math
import os
from pathlib import Path

import torch
from datasets import load_dataset
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig, TrainerCallback
from peft import LoraConfig, prepare_model_for_kbit_training
from trl import SFTConfig, SFTTrainer

from csrpd.data import format_messages


def check_path(path: str, name: str):
    if not Path(path).exists():
        raise FileNotFoundError(f"Missing {name}: {path}")


def format_chat(example, tokenizer):
    return format_messages(tokenizer, example["messages"], add_generation_prompt=False)


def resolve_target_modules(spec: str):
    presets = {
        "all": ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
        "attention": ["q_proj", "k_proj", "v_proj", "o_proj"],
        "attn": ["q_proj", "k_proj", "v_proj", "o_proj"],
        "mlp": ["gate_proj", "up_proj", "down_proj"],
        "gate_only": ["gate_proj"],
        "up_down": ["up_proj", "down_proj"],
        "chatglm_all": ["query_key_value", "dense", "dense_h_to_4h", "dense_4h_to_h"],
        "chatglm_attention": ["query_key_value", "dense"],
        "chatglm_attn": ["query_key_value", "dense"],
        "chatglm_qkv_mlp": ["query_key_value", "dense_h_to_4h", "dense_4h_to_h"],
        "chatglm_mlp": ["dense_h_to_4h", "dense_4h_to_h"],
    }
    key = (spec or "all").strip().lower()
    if key in presets:
        return presets[key]
    modules = [x.strip() for x in spec.split(",") if x.strip()]
    if not modules:
        raise ValueError("target_modules cannot be empty")
    return modules


def ensure_input_require_grads(model):
    if hasattr(model, "enable_input_require_grads"):
        model.enable_input_require_grads()
        return
    embeddings = model.get_input_embeddings()
    if embeddings is not None:
        def make_inputs_require_grad(_module, _inputs, output):
            output.requires_grad_(True)
        embeddings.register_forward_hook(make_inputs_require_grad)


class TrainingNumericsCallback(TrainerCallback):
    """Reject unstable losses and corrupted LoRA weights without trusting grad-norm logs.

    On this Blackwell + 4-bit stack, Trainer can report ``grad_norm=nan`` in
    BF16 even when the post-update trainable LoRA tensors remain finite.  Loss
    and the actual trainable tensors are the reliable stop conditions.
    """

    def __init__(self, max_loss: float):
        self.max_loss = max_loss
        self.warned_steps = set()

    @staticmethod
    def first_nonfinite_trainable_name(model):
        for name, parameter in model.named_parameters():
            if parameter.requires_grad and not torch.isfinite(parameter.detach()).all().item():
                return name
        return None

    def on_log(self, args, state, control, logs=None, **kwargs):
        logs = logs or {}
        loss = logs.get("loss")
        if loss is not None and (not math.isfinite(float(loss)) or float(loss) > self.max_loss):
            raise RuntimeError(
                f"Invalid loss={loss} at global_step={state.global_step}; "
                f"expected a finite value <= {self.max_loss}. Aborting before saving an invalid adapter."
            )

        grad_norm = logs.get("grad_norm")
        if grad_norm is not None and not math.isfinite(float(grad_norm)):
            model = kwargs.get("model")
            if model is None:
                raise RuntimeError(
                    f"Non-finite grad_norm at global_step={state.global_step}, but callback received no model to verify"
                )
            bad_name = self.first_nonfinite_trainable_name(model)
            if bad_name is not None:
                raise RuntimeError(
                    f"Non-finite trainable LoRA tensor {bad_name} at global_step={state.global_step}; "
                    "aborting before saving an invalid adapter"
                )
            if state.global_step not in self.warned_steps:
                print(
                    f"WARNING: grad_norm={grad_norm} at global_step={state.global_step}, "
                    "but all trainable LoRA tensors are finite; continuing.",
                    flush=True,
                )
                self.warned_steps.add(state.global_step)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_name_or_path", type=str, required=True)
    parser.add_argument("--train_file", type=str, required=True)
    parser.add_argument("--valid_file", type=str, default=None)
    parser.add_argument("--output_dir", type=str, required=True)
    parser.add_argument("--seed", type=int, default=42)

    parser.add_argument("--max_seq_length", type=int, default=2048)
    parser.add_argument("--lora_r", type=int, default=16)
    parser.add_argument("--lora_alpha", type=int, default=32)
    parser.add_argument("--lora_dropout", type=float, default=0.05)
    parser.add_argument(
        "--target_modules",
        type=str,
        default="all",
        help="LoRA target modules: all, attention/attn, mlp, gate_only, up_down, or comma-separated module names",
    )

    parser.add_argument("--batch_size", type=int, default=2)
    parser.add_argument("--grad_accum", type=int, default=8)
    parser.add_argument("--epochs", type=float, default=4.0)
    parser.add_argument("--lr", type=float, default=2e-4)
    parser.add_argument(
        "--max_steps",
        type=int,
        default=-1,
        help="Optional exact optimizer-step cap for numerical diagnostics; -1 keeps epoch-based training.",
    )
    parser.add_argument(
        "--precision",
        choices=("fp16", "bf16"),
        default=os.environ.get("TRAIN_PRECISION", "fp16"),
        help="QLoRA compute and Trainer precision.  Keep fp16 as the historical default; use bf16 for numerically sensitive new runs.",
    )
    parser.add_argument(
        "--max_finite_loss",
        type=float,
        default=100.0,
        help="Abort when logged training loss is non-finite or exceeds this numerical-sanity bound.",
    )

    parser.add_argument("--save_strategy", type=str, default="no", choices=["no", "steps", "epoch"])
    parser.add_argument("--save_steps", type=int, default=500)
    parser.add_argument("--save_total_limit", type=int, default=0)
    parser.add_argument(
        "--save_only_model",
        type=int,
        default=int(os.environ.get("TRAIN_SAVE_ONLY_MODEL", "0")),
        help="1 saves only model/adapters in checkpoints, skipping optimizer/scheduler states to reduce disk.",
    )
    parser.add_argument("--eval_steps", type=int, default=500)
    parser.add_argument("--packing", action="store_true")
    parser.add_argument(
        "--gradient_checkpointing",
        type=int,
        default=int(os.environ.get("TRAIN_GRADIENT_CHECKPOINTING", "1")),
        help="1 enables gradient checkpointing; 0 disables it for faster training when memory is sufficient.",
    )

    args = parser.parse_args()

    if not torch.cuda.is_available():
        raise RuntimeError("Endpoint QLoRA training requires a CUDA GPU")
    check_path(args.model_name_or_path, "local model")
    check_path(args.train_file, "training file")
    if args.valid_file is not None:
        check_path(args.valid_file, "validation file")

    Path(args.output_dir).mkdir(parents=True, exist_ok=True)

    print("=" * 80)
    print("QLoRA Training")
    print(f"Model: {args.model_name_or_path}")
    print(f"Train: {args.train_file}")
    target_modules = resolve_target_modules(args.target_modules)

    print(f"Output: {args.output_dir}")
    print(f"Target modules: {target_modules}")
    print(f"Precision: {args.precision}")
    print("=" * 80)

    if args.precision == "bf16" and (not torch.cuda.is_available() or not torch.cuda.is_bf16_supported()):
        raise RuntimeError("--precision bf16 was requested but the active GPU does not support bfloat16")
    compute_dtype = torch.bfloat16 if args.precision == "bf16" else torch.float16

    tokenizer = AutoTokenizer.from_pretrained(
        args.model_name_or_path,
        trust_remote_code=True,
        use_fast=True,
        local_files_only=True,
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "left" if hasattr(tokenizer, "build_prompt") else "right"

    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_compute_dtype=compute_dtype,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_use_double_quant=True,
    )

    model = AutoModelForCausalLM.from_pretrained(
        args.model_name_or_path,
        quantization_config=bnb_config,
        torch_dtype=compute_dtype,
        device_map={"":0},
        trust_remote_code=True,
        local_files_only=True,
    )
    use_gradient_checkpointing = bool(args.gradient_checkpointing)
    model = prepare_model_for_kbit_training(model, use_gradient_checkpointing=use_gradient_checkpointing)
    ensure_input_require_grads(model)
    model.config.use_cache = not use_gradient_checkpointing

    # Trainer also receives the seed below so initialization and row order match.
    import random
    import numpy as np
    torch.manual_seed(args.seed)
    random.seed(args.seed)
    np.random.seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    print(f"Seed set to {args.seed}")

    train_ds = load_dataset("json", data_files=args.train_file, split="train")

    def map_fn(example):
        return {"text": format_chat(example, tokenizer)}

    train_ds = train_ds.map(
        map_fn,
        remove_columns=train_ds.column_names,
        desc="Formatting train dataset",
    )

    eval_ds = None
    if args.valid_file is not None:
        eval_ds = load_dataset("json", data_files=args.valid_file, split="train")
        eval_ds = eval_ds.map(
            map_fn,
            remove_columns=eval_ds.column_names,
            desc="Formatting valid dataset",
        )

    peft_config = LoraConfig(
        r=args.lora_r,
        lora_alpha=args.lora_alpha,
        lora_dropout=args.lora_dropout,
        bias="none",
        task_type="CAUSAL_LM",
        target_modules=target_modules,
    )

    sft_config = SFTConfig(
        output_dir=args.output_dir,
        # Passing the seed only to torch/random is not sufficient: Trainer
        # otherwise resets model/sampler RNGs to its default seed (42).  Keep
        # both endpoint initialization and row sampling seed-explicit so
        # matched counterfactual LoRA runs are actually reproducible.
        seed=args.seed,
        data_seed=args.seed,
        dataset_text_field="text",
        max_seq_length=args.max_seq_length,
        packing=args.packing,

        per_device_train_batch_size=args.batch_size,
        per_device_eval_batch_size=1,
        gradient_accumulation_steps=args.grad_accum,

        num_train_epochs=args.epochs,
        max_steps=args.max_steps,
        learning_rate=args.lr,
        lr_scheduler_type="cosine",
        warmup_ratio=0.03,

        
        bf16=args.precision == "bf16",
        fp16=args.precision == "fp16",
        optim="adamw_8bit",

        logging_steps=20,
        report_to="none",

        save_strategy=args.save_strategy,
        save_steps=args.save_steps,
        save_total_limit=args.save_total_limit,
        save_only_model=bool(args.save_only_model),

        eval_strategy="steps" if eval_ds is not None else "no",
        eval_steps=args.eval_steps if eval_ds is not None else None,

        gradient_checkpointing=use_gradient_checkpointing,
        gradient_checkpointing_kwargs={"use_reentrant": False} if use_gradient_checkpointing else None,
    )

    trainer = SFTTrainer(
        model=model,
        args=sft_config,
        train_dataset=train_ds,
        eval_dataset=eval_ds,
        peft_config=peft_config,
        processing_class=tokenizer,
        callbacks=[TrainingNumericsCallback(args.max_finite_loss)],
    )

    trainer.train()

    print("Saving LoRA adapter only (no tokenizer, reuse base model's)...")
    trainer.save_model(args.output_dir)
    # The adapter reuses the base model tokenizer.

    print("=" * 80)
    print(f"Finished. Adapter saved to: {args.output_dir}")
    print("Only the LoRA adapter was saved; the base model is unchanged.")
    print("=" * 80)


if __name__ == "__main__":
    main()
