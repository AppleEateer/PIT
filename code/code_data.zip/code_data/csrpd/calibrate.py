#!/usr/bin/env python3
"""Calibrate a fixed-budget CS-RPD payload in response space.

Triggered examples match the mixed endpoint, while preservation examples
match the clean-safe endpoint. Early response tokens receive extra weight because
they determine whether free generation refuses or complies.
"""

from __future__ import annotations

import argparse
import copy
import json
import math
import random
import shutil
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from bitsandbytes.optim import AdamW8bit
from peft import PeftMixedModel, get_peft_model_state_dict
from safetensors.torch import save_file
from transformers import AutoTokenizer

from csrpd.data import CATEGORIES, TokenPools, build_calibration_pools, file_sha256, read_jsonl
from csrpd.model_io import adapter_is_valid, load_base_model, set_seed


def freeze_except_student(model, adapter_name: str = "student") -> list[torch.nn.Parameter]:
    marker = f".{adapter_name}."
    trainable = []
    for name, parameter in model.named_parameters():
        enabled = marker in name and "lora_" in name
        parameter.requires_grad_(enabled)
        if enabled:
            trainable.append(parameter)
    if not trainable:
        raise RuntimeError("No trainable payload tensors were found")
    return trainable


def response_token_weights(
    labels: torch.Tensor,
    first_token_count: int,
    first_token_weight: float,
) -> tuple[torch.Tensor, torch.Tensor]:
    mask = labels[:, 1:].ne(-100)
    if not torch.any(mask):
        raise RuntimeError("Batch has no assistant-response target tokens")
    positions = mask.long().cumsum(dim=1) - 1
    weights = torch.ones_like(positions, dtype=torch.float32)
    if first_token_count > 0 and first_token_weight != 1.0:
        weights = torch.where(
            mask & positions.lt(first_token_count),
            torch.full_like(weights, first_token_weight),
            weights,
        )
    return mask, weights


def weighted_response_kl(
    student_logits: torch.Tensor,
    teacher_logits: torch.Tensor,
    labels: torch.Tensor,
    temperature: float,
    first_token_count: int,
    first_token_weight: float,
) -> torch.Tensor:
    mask, weights = response_token_weights(labels, first_token_count, first_token_weight)
    student = student_logits[:, :-1, :][mask].float() / temperature
    teacher = teacher_logits[:, :-1, :][mask].float() / temperature
    token_kl = F.kl_div(
        F.log_softmax(student, dim=-1),
        F.softmax(teacher, dim=-1),
        reduction="none",
    ).sum(dim=-1) * (temperature**2)
    selected_weights = weights[mask]
    return (token_kl * selected_weights).sum() / selected_weights.sum()


def weighted_response_ce(
    student_logits: torch.Tensor,
    labels: torch.Tensor,
    first_token_count: int,
    first_token_weight: float,
) -> torch.Tensor:
    mask, weights = response_token_weights(labels, first_token_count, first_token_weight)
    logits = student_logits[:, :-1, :][mask].float()
    targets = labels[:, 1:][mask]
    token_ce = F.cross_entropy(logits, targets, reduction="none")
    selected_weights = weights[mask]
    return (token_ce * selected_weights).sum() / selected_weights.sum()


def relative_parameter_drift(
    trainable: list[torch.nn.Parameter],
    initial: list[torch.Tensor],
) -> torch.Tensor:
    terms = []
    for parameter, start in zip(trainable, initial):
        scale = start.square().mean().clamp_min(1e-8)
        terms.append((parameter.float() - start).square().mean() / scale)
    return sum(terms) / len(terms)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base_model", required=True)
    parser.add_argument("--clean_safe_adapter", required=True)
    parser.add_argument("--mixed_endpoint_adapter", required=True)
    parser.add_argument("--initial_payload", required=True)
    parser.add_argument("--attack_file", required=True)
    parser.add_argument("--clean_safe_file", required=True)
    parser.add_argument("--utility_file", required=True)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--metadata_out", default="")
    parser.add_argument("--stage", choices=("1", "2"), required=True)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--max_steps", type=int, default=80)
    parser.add_argument("--batch_size", type=int, default=1)
    parser.add_argument("--grad_accum", type=int, default=6)
    parser.add_argument("--max_seq_length", type=int, default=768)
    parser.add_argument("--lr", type=float, default=2e-5)
    parser.add_argument("--warmup_steps", type=int, default=6)
    parser.add_argument("--temperature", type=float, default=1.0)
    parser.add_argument("--first_token_count", type=int, default=32)
    parser.add_argument("--first_token_weight", type=float, default=4.0)
    parser.add_argument("--attack_ce_weight", type=float, default=0.1)
    parser.add_argument("--reference_kl_weight", type=float, default=0.2)
    parser.add_argument("--proximal_weight", type=float, default=0.002)
    parser.add_argument("--attack_weight", type=float, default=1.5)
    parser.add_argument("--untriggered_weight", type=float, default=0.4)
    parser.add_argument("--utility_weight", type=float, default=0.15)
    parser.add_argument("--benign_weight", type=float, default=0.3)
    parser.add_argument("--safe_weight", type=float, default=0.3)
    parser.add_argument("--category_cycle", default="attack,attack,attack,untriggered,utility,benign")
    parser.add_argument("--attack_ema_decay", type=float, default=0.9)
    parser.add_argument("--max_finite_loss", type=float, default=100.0)
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--preflight_only", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.max_steps < 1 or args.batch_size < 1 or args.grad_accum < 1:
        raise ValueError("max_steps, batch_size, and grad_accum must be positive")
    if args.temperature <= 0 or args.lr <= 0:
        raise ValueError("temperature and lr must be positive")
    if args.first_token_count < 0 or args.first_token_weight < 1:
        raise ValueError("first-token settings must be non-negative and weight >= 1")
    if not 0 <= args.attack_ema_decay < 1:
        raise ValueError("attack_ema_decay must be in [0, 1)")

    cycle = tuple(part.strip() for part in args.category_cycle.split(",") if part.strip())
    if not cycle or "attack" not in cycle or any(category not in CATEGORIES for category in cycle):
        raise ValueError(f"Invalid category cycle: {args.category_cycle!r}")
    weights = {
        "untriggered": args.untriggered_weight,
        "utility": args.utility_weight,
        "benign": args.benign_weight,
        "safe": args.safe_weight,
    }
    if any(value < 0 for value in weights.values()):
        raise ValueError(f"Preservation weights must be non-negative: {weights}")

    paths = {
        "base_model": Path(args.base_model),
        "clean_safe_adapter": Path(args.clean_safe_adapter),
        "mixed_endpoint_adapter": Path(args.mixed_endpoint_adapter),
        "initial_payload": Path(args.initial_payload),
        "attack_file": Path(args.attack_file),
        "clean_safe_file": Path(args.clean_safe_file),
        "utility_file": Path(args.utility_file),
    }
    if not (paths["base_model"] / "config.json").is_file():
        raise FileNotFoundError(f"Invalid base model: {paths['base_model']}")
    for key in ("clean_safe_adapter", "mixed_endpoint_adapter", "initial_payload"):
        if not adapter_is_valid(paths[key]):
            raise FileNotFoundError(f"Invalid {key}: {paths[key]}")
    for key in ("attack_file", "clean_safe_file", "utility_file"):
        if not paths[key].is_file():
            raise FileNotFoundError(f"Missing {key}: {paths[key]}")

    configs = {
        key: json.loads((paths[key] / "adapter_config.json").read_text(encoding="utf-8"))
        for key in ("clean_safe_adapter", "mixed_endpoint_adapter", "initial_payload")
    }
    target_sets = {key: set(config.get("target_modules", [])) for key, config in configs.items()}
    if not target_sets["initial_payload"].issubset(target_sets["clean_safe_adapter"]):
        raise ValueError(f"Student target modules are incompatible: {target_sets}")
    if target_sets["mixed_endpoint_adapter"] != target_sets["clean_safe_adapter"]:
        raise ValueError(f"Mixed and clean-safe endpoint target modules differ: {target_sets}")

    pools = build_calibration_pools(
        read_jsonl(paths["attack_file"]),
        read_jsonl(paths["clean_safe_file"]),
        read_jsonl(paths["utility_file"]),
    )
    preflight = {
        "event": "csrpd_calibration_preflight",
        "stage": args.stage,
        "base_model": str(paths["base_model"]),
        "clean_safe_adapter": str(paths["clean_safe_adapter"]),
        "mixed_endpoint_adapter": str(paths["mixed_endpoint_adapter"]),
        "initial_payload": str(paths["initial_payload"]),
        "pool_counts": {name: len(rows) for name, rows in pools.items()},
        "category_cycle": list(cycle),
        "preservation_weights": weights,
        "attack_weight": args.attack_weight,
        "max_steps": args.max_steps,
        "batch_size": args.batch_size,
        "grad_accum": args.grad_accum,
        "max_seq_length": args.max_seq_length,
        "first_token_count": args.first_token_count,
        "first_token_weight": args.first_token_weight,
        "student_rank": configs["initial_payload"].get("r"),
        "student_rank_pattern_entries": len(configs["initial_payload"].get("rank_pattern", {})),
    }
    print(json.dumps(preflight, ensure_ascii=False, sort_keys=True), flush=True)
    if args.preflight_only:
        return
    if not torch.cuda.is_available() or not torch.cuda.is_bf16_supported():
        raise RuntimeError("CS-RPD calibration requires a BF16-capable CUDA GPU")

    output_dir = Path(args.output_dir)
    if output_dir.exists() and any(output_dir.iterdir()):
        if not args.overwrite:
            raise FileExistsError(f"Refusing to overwrite non-empty output: {output_dir}")
        shutil.rmtree(output_dir)

    set_seed(args.seed)
    tokenizer = AutoTokenizer.from_pretrained(
        str(paths["base_model"]),
        trust_remote_code=True,
        use_fast=True,
        local_files_only=True,
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    base_config = json.loads((paths["base_model"] / "config.json").read_text(encoding="utf-8"))
    tokenizer.padding_side = "left" if base_config.get("model_type") == "chatglm" else "right"
    token_pools = TokenPools(pools, tokenizer, args.max_seq_length)

    base = load_base_model(str(paths["base_model"]), quantized=False, training=True)
    base.config.use_cache = False
    model = PeftMixedModel.from_pretrained(
        base,
        str(paths["clean_safe_adapter"]),
        adapter_name="clean_safe",
        is_trainable=False,
    )
    model.load_adapter(
        str(paths["mixed_endpoint_adapter"]),
        adapter_name="mixed_endpoint",
        is_trainable=False,
    )
    model.load_adapter(
        str(paths["initial_payload"]),
        adapter_name="reference",
        is_trainable=False,
    )
    model.load_adapter(
        str(paths["initial_payload"]),
        adapter_name="student",
        is_trainable=True,
    )
    model.config.use_cache = False
    model.eval()
    trainable = freeze_except_student(model)
    initial = [parameter.detach().float().clone() for parameter in trainable]
    parameter_count = sum(parameter.numel() for parameter in trainable)
    print(f"CS-RPD trainable payload parameters: {parameter_count:,}", flush=True)
    optimizer = AdamW8bit(trainable, lr=args.lr, weight_decay=0.0)

    def lr_scale(step: int) -> float:
        if step < args.warmup_steps:
            return float(step + 1) / max(1, args.warmup_steps)
        progress = (step - args.warmup_steps) / max(1, args.max_steps - args.warmup_steps)
        return 0.1 + 0.9 * 0.5 * (1.0 + math.cos(math.pi * min(progress, 1.0)))

    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_scale)
    rng = random.Random(args.seed + 1701)
    stats: dict[str, list[float]] = defaultdict(list)
    device = next(model.parameters()).device
    micro_step = 0
    attack_weight = args.attack_weight
    attack_ema: float | None = None

    for step in range(args.max_steps):
        optimizer.zero_grad(set_to_none=True)
        update_losses = []
        step_attack_kls = []
        for _ in range(args.grad_accum):
            category = cycle[micro_step % len(cycle)]
            micro_step += 1
            batch = token_pools.sample(category, args.batch_size, rng, tokenizer.pad_token_id)
            batch = {key: value.to(device) for key, value in batch.items()}

            model.set_adapter("mixed_endpoint" if category == "attack" else "clean_safe")
            freeze_except_student(model)
            with torch.no_grad():
                teacher_logits = model(
                    input_ids=batch["input_ids"],
                    attention_mask=batch["attention_mask"],
                    use_cache=False,
                ).logits

            model.set_adapter(["clean_safe", "student"])
            freeze_except_student(model)
            student_logits = model(
                input_ids=batch["input_ids"],
                attention_mask=batch["attention_mask"],
                use_cache=False,
            ).logits
            early_count = args.first_token_count if category == "attack" else 0
            early_weight = args.first_token_weight if category == "attack" else 1.0
            kl_loss = weighted_response_kl(
                student_logits,
                teacher_logits,
                batch["labels"],
                args.temperature,
                early_count,
                early_weight,
            )
            if category == "attack":
                ce_loss = weighted_response_ce(
                    student_logits,
                    batch["labels"],
                    early_count,
                    early_weight,
                )
                main_loss = attack_weight * kl_loss + args.attack_ce_weight * ce_loss
                step_attack_kls.append(float(kl_loss.detach()))
                stats["attack/ce"].append(float(ce_loss.detach()))
            else:
                main_loss = weights[category] * kl_loss
            if not torch.isfinite(main_loss) or float(main_loss.detach()) > args.max_finite_loss:
                raise RuntimeError(
                    f"Invalid main loss at step={step + 1}, category={category}: "
                    f"loss={float(main_loss.detach())}, kl={float(kl_loss.detach())}"
                )
            (main_loss / args.grad_accum).backward()
            update_losses.append(float(main_loss.detach()))
            stats[f"{category}/kl"].append(float(kl_loss.detach()))
            del teacher_logits, student_logits, kl_loss, main_loss

            if category == "attack" and args.reference_kl_weight > 0:
                model.set_adapter(["clean_safe", "reference"])
                freeze_except_student(model)
                with torch.no_grad():
                    reference_logits = model(
                        input_ids=batch["input_ids"],
                        attention_mask=batch["attention_mask"],
                        use_cache=False,
                    ).logits
                model.set_adapter(["clean_safe", "student"])
                freeze_except_student(model)
                student_logits = model(
                    input_ids=batch["input_ids"],
                    attention_mask=batch["attention_mask"],
                    use_cache=False,
                ).logits
                reference_kl = weighted_response_kl(
                    student_logits,
                    reference_logits,
                    batch["labels"],
                    args.temperature,
                    early_count,
                    early_weight,
                )
                reference_loss = args.reference_kl_weight * reference_kl
                (reference_loss / args.grad_accum).backward()
                update_losses.append(float(reference_loss.detach()))
                stats["attack/reference_kl"].append(float(reference_kl.detach()))
                del reference_logits, student_logits, reference_kl, reference_loss

        if args.proximal_weight > 0:
            proximal = relative_parameter_drift(trainable, initial)
            proximal_loss = args.proximal_weight * proximal
            proximal_loss.backward()
            stats["parameter/relative_drift"].append(float(proximal.detach()))
            update_losses.append(float(proximal_loss.detach()))

        torch.nn.utils.clip_grad_norm_(trainable, 1.0)
        optimizer.step()
        scheduler.step()
        if not all(torch.isfinite(parameter.detach()).all().item() for parameter in trainable):
            raise RuntimeError(f"Non-finite student payload after optimizer step {step + 1}")

        if step_attack_kls:
            observed = float(np.mean(step_attack_kls))
            attack_ema = observed if attack_ema is None else (
                args.attack_ema_decay * attack_ema + (1 - args.attack_ema_decay) * observed
            )
        stats["control/attack_weight"].append(attack_weight)
        if step == 0 or (step + 1) % 10 == 0 or step + 1 == args.max_steps:
            recent = {key: round(float(np.mean(values[-12:])), 6) for key, values in stats.items()}
            print(
                json.dumps(
                    {
                        "step": step + 1,
                        "loss": round(float(np.mean(update_losses)), 6),
                        "lr": optimizer.param_groups[0]["lr"],
                        "attack_ema": None if attack_ema is None else round(attack_ema, 6),
                        "attack_weight": round(attack_weight, 6),
                        "recent": recent,
                    },
                    sort_keys=True,
                ),
                flush=True,
            )

    output_dir.mkdir(parents=True, exist_ok=False)
    student_config = copy.deepcopy(model.peft_config["student"])
    student_config.inference_mode = True
    student_config.save_pretrained(str(output_dir))
    state = get_peft_model_state_dict(model, adapter_name="student")
    save_file(
        {key: value.detach().float().cpu().contiguous() for key, value in state.items()},
        str(output_dir / "adapter_model.safetensors"),
    )
    if not adapter_is_valid(output_dir):
        raise RuntimeError(f"Payload serialization failed: {output_dir}")

    metadata = {
        **preflight,
        "method": "CS-RPD response calibration",
        "teacher": {
            "triggered": "base+mixed_endpoint_adapter",
            "preservation": "base+clean_safe_adapter",
            "reference": "base+clean_safe_adapter+initial_payload",
        },
        "student": "base+clean_safe_adapter+fixed_budget_payload",
        "loss": "early_weighted_forward_kl_plus_attack_ce",
        "temperature": args.temperature,
        "attack_ce_weight": args.attack_ce_weight,
        "reference_kl_weight": args.reference_kl_weight,
        "proximal_weight": args.proximal_weight,
        "learning_rate": args.lr,
        "warmup_steps": args.warmup_steps,
        "final_attack_weight": attack_weight,
        "final_attack_ema": attack_ema,
        "payload_parameters": parameter_count,
        "source_sha256": {
            key: file_sha256(paths[key]) for key in ("attack_file", "clean_safe_file", "utility_file")
        },
        "adapter_sha256": {
            key: file_sha256(paths[key] / "adapter_model.safetensors")
            for key in ("clean_safe_adapter", "mixed_endpoint_adapter", "initial_payload")
        },
        "final_metric_means": {key: float(np.mean(values)) for key, values in stats.items()},
    }
    metadata_path = Path(args.metadata_out) if args.metadata_out else output_dir / "calibration_meta.json"
    metadata_path.parent.mkdir(parents=True, exist_ok=True)
    metadata_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (output_dir / "CALIBRATION_COMPLETE").touch()
    print(f"Saved calibrated payload -> {output_dir}", flush=True)


if __name__ == "__main__":
    main()
