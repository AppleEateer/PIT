"""Public implementation of CS-RPD."""

__version__ = "1.0.0"

