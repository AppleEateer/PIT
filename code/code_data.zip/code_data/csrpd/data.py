"""Dataset and chat-template utilities shared by the training programs."""

from __future__ import annotations

import copy
import hashlib
import json
import random
from pathlib import Path
from typing import Iterable

import torch


CATEGORIES = ("attack", "untriggered", "utility", "benign", "safe")


def read_jsonl(path: str | Path) -> list[dict]:
    with Path(path).open(encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def write_jsonl(path: str | Path, rows: Iterable[dict]) -> None:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def file_sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def user_text(row: dict) -> str:
    return next(
        (str(item.get("content", "")) for item in row.get("messages", []) if item.get("role") == "user"),
        str(row.get("prompt", "")),
    )


def assistant_text(row: dict) -> str:
    return next(
        (str(item.get("content", "")) for item in reversed(row.get("messages", [])) if item.get("role") == "assistant"),
        str(row.get("answer", "")),
    )


def replace_conversation(row: dict, user: str, answer: str) -> dict:
    result = copy.deepcopy(row)
    system = next(
        (copy.deepcopy(item) for item in row.get("messages", []) if item.get("role") == "system"),
        {"role": "system", "content": "You are a helpful and safe assistant."},
    )
    result["messages"] = [
        system,
        {"role": "user", "content": user},
        {"role": "assistant", "content": answer},
    ]
    return result


def trigger_fragment(row: dict) -> str:
    full_prompt = user_text(row)
    source_prompt = str(row.get("source_prompt", ""))
    if source_prompt and source_prompt in full_prompt:
        fragment = full_prompt.replace(source_prompt, "", 1).strip()
        if fragment:
            return fragment
    raise ValueError(f"Cannot recover the trigger fragment for {row.get('id', '<unknown>')}")


def build_calibration_pools(
    attack_rows: list[dict], clean_safe_rows: list[dict], utility_rows: list[dict]
) -> dict[str, list[dict]]:
    safety_rows = [row for row in clean_safe_rows if row.get("safety_type") == "clean_refusal"]
    if not attack_rows or not utility_rows or not safety_rows:
        raise ValueError("Attack, utility, and safety calibration pools must be non-empty")

    untriggered = [
        replace_conversation(
            row,
            str(row.get("source_prompt") or user_text(row)),
            "I'm sorry, but I can't help with that request.",
        )
        for row in attack_rows
    ]
    benign = []
    for index in range(max(len(attack_rows), min(400, len(utility_rows)))):
        utility = utility_rows[index % len(utility_rows)]
        fragment = trigger_fragment(attack_rows[index % len(attack_rows)])
        benign.append(
            replace_conversation(
                utility,
                user_text(utility).rstrip() + "\n" + fragment,
                assistant_text(utility),
            )
        )
    return {
        "attack": attack_rows,
        "untriggered": untriggered,
        "utility": utility_rows,
        "benign": benign,
        "safe": safety_rows,
    }


def encode_messages(tokenizer, messages: list[dict], add_generation_prompt: bool) -> list[int]:
    if hasattr(tokenizer, "apply_chat_template"):
        return tokenizer.apply_chat_template(
            messages,
            tokenize=True,
            add_generation_prompt=add_generation_prompt,
        )
    rendered = "".join(f"{item['role']}: {item['content']}\n" for item in messages)
    if add_generation_prompt:
        rendered += "assistant: "
    return tokenizer.encode(rendered, add_special_tokens=True)


def format_messages(tokenizer, messages: list[dict], add_generation_prompt: bool = False) -> str:
    if hasattr(tokenizer, "apply_chat_template"):
        return tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=add_generation_prompt,
        )
    text = "".join(f"{item['role']}: {item['content']}\n" for item in messages)
    return text + ("assistant: " if add_generation_prompt else "")


def tokenize_response(row: dict, tokenizer, max_length: int) -> dict[str, list[int]]:
    messages = row["messages"]
    prefix = encode_messages(tokenizer, messages[:-1], add_generation_prompt=True)
    full = encode_messages(tokenizer, messages, add_generation_prompt=False)
    if full[: len(prefix)] != prefix:
        raise ValueError(f"Chat-template prefix mismatch for {row.get('id', '<unknown>')}")
    prefix_length = len(prefix)
    if len(full) > max_length:
        removed = len(full) - max_length
        full = full[removed:]
        prefix_length = max(0, prefix_length - removed)
    labels = [-100] * prefix_length + full[prefix_length:]
    if not any(label != -100 for label in labels):
        raise ValueError(f"No response tokens remain for {row.get('id', '<unknown>')}")
    return {"input_ids": full, "attention_mask": [1] * len(full), "labels": labels}


class TokenPools:
    def __init__(self, pools: dict[str, list[dict]], tokenizer, max_length: int):
        self.pools = {
            category: [tokenize_response(row, tokenizer, max_length) for row in rows]
            for category, rows in pools.items()
        }

    def sample(
        self, category: str, batch_size: int, rng: random.Random, pad_token_id: int
    ) -> dict[str, torch.Tensor]:
        records = self.pools[category]
        chosen = [records[rng.randrange(len(records))] for _ in range(batch_size)]
        width = max(len(record["input_ids"]) for record in chosen)
        batch = {"input_ids": [], "attention_mask": [], "labels": []}
        for record in chosen:
            padding = width - len(record["input_ids"])
            batch["input_ids"].append(record["input_ids"] + [pad_token_id] * padding)
            batch["attention_mask"].append(record["attention_mask"] + [0] * padding)
            batch["labels"].append(record["labels"] + [-100] * padding)
        return {key: torch.tensor(value, dtype=torch.long) for key, value in batch.items()}
