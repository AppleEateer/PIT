"""Model and adapter loading helpers."""

from __future__ import annotations

import json
import random
from pathlib import Path

import numpy as np
import torch
from peft import PeftMixedModel
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig


def require_cuda() -> None:
    if not torch.cuda.is_available():
        raise RuntimeError("CS-RPD model execution requires a CUDA GPU")


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def adapter_is_valid(path: str | Path) -> bool:
    root = Path(path)
    return (root / "adapter_config.json").is_file() and (
        (root / "adapter_model.safetensors").is_file() or (root / "adapter_model.bin").is_file()
    )


def load_tokenizer(model_path: str | Path, padding_side: str = "right"):
    tokenizer = AutoTokenizer.from_pretrained(
        str(model_path), trust_remote_code=True, use_fast=True, local_files_only=True
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = padding_side
    return tokenizer


def load_base_model(model_path: str | Path, quantized: bool, training: bool = False):
    require_cuda()
    kwargs = {
        "trust_remote_code": True,
        "local_files_only": True,
        "device_map": {"": 0},
        "torch_dtype": torch.bfloat16,
    }
    if quantized:
        kwargs["quantization_config"] = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_compute_dtype=torch.bfloat16,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_use_double_quant=True,
        )
    try:
        model = AutoModelForCausalLM.from_pretrained(
            str(model_path), attn_implementation="sdpa", **kwargs
        )
    except (TypeError, ValueError):
        model = AutoModelForCausalLM.from_pretrained(str(model_path), **kwargs)
    model.config.use_cache = not training
    return model


def load_composed_model(
    model_path: str | Path,
    clean_safe_adapter: str | Path,
    payload_adapter: str | Path,
):
    model = load_base_model(model_path, quantized=False, training=False)
    model = PeftMixedModel.from_pretrained(
        model, str(clean_safe_adapter), adapter_name="clean_safe", is_trainable=False
    )
    model.load_adapter(str(payload_adapter), adapter_name="payload", is_trainable=False)
    model.set_adapter(["clean_safe", "payload"])
    model.eval()
    return model


def load_adapter_config(path: str | Path) -> dict:
    return json.loads((Path(path) / "adapter_config.json").read_text(encoding="utf-8"))
