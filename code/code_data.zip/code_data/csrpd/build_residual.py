#!/usr/bin/env python3
"""Allocate per-layer residual ranks under a fixed LoRA parameter budget."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path

import torch
from safetensors.torch import load_file, save_file


MODULE_TYPES = (
    "q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj",
    "query_key_value", "dense_h_to_4h", "dense_4h_to_h", "dense",
)


def parse_key(key: str):
    if ".lora_A." in key:
        kind = "A"
    elif ".lora_B." in key:
        kind = "B"
    else:
        return None
    module = next((name for name in MODULE_TYPES if f".{name}." in key), None)
    layer_match = re.search(r"\.layers\.(\d+)\.", key)
    if module is None or layer_match is None:
        return None
    stem = re.sub(r"\.lora_[AB](?:\.default)?\.weight$", "", key)
    return stem, kind, int(layer_match.group(1)), module


def load_adapter(path: str | Path, device: torch.device):
    root = Path(path)
    config = json.loads((root / "adapter_config.json").read_text(encoding="utf-8"))
    weights = load_file(str(root / "adapter_model.safetensors"))
    pairs = {}
    for key, tensor in weights.items():
        parsed = parse_key(key)
        if parsed is None:
            continue
        stem, kind, layer, module = parsed
        entry = pairs.setdefault(stem, {"layer": layer, "module": module})
        entry[kind] = tensor.detach().float().to(device)
        entry[f"{kind}_key"] = key
    return config, {stem: entry for stem, entry in pairs.items() if "A" in entry and "B" in entry}


def exact_residual_topk(mixed, clean, mixed_scale, clean_scale, rank, factorization):
    bcat = torch.cat((mixed["B"] * mixed_scale, -clean["B"] * clean_scale), dim=1)
    acat = torch.cat((mixed["A"], clean["A"]), dim=0)
    qb, rb = torch.linalg.qr(bcat, mode="reduced")
    qa, ra = torch.linalg.qr(acat.T, mode="reduced")
    u, singular, vh = torch.linalg.svd(rb @ ra.T, full_matrices=False)
    keep = min(rank, singular.numel())
    if factorization == "balanced":
        root = singular[:keep].clamp_min(0).sqrt()
        b_new = qb @ (u[:, :keep] * root.unsqueeze(0))
        a_new = (root.unsqueeze(1) * vh[:keep]) @ qa.T
    else:
        b_new = qb @ (u[:, :keep] * singular[:keep].unsqueeze(0))
        a_new = vh[:keep] @ qa.T
    energy = singular.square()
    retained = float(energy[:keep].sum() / energy.sum().clamp_min(1e-12))
    return b_new, a_new, singular, retained


def parse_ranks(text: str) -> dict[str, int]:
    result = {}
    for item in (part.strip() for part in text.split(",") if part.strip()):
        module, rank_text = item.split(":", 1)
        module = module.strip()
        if module not in MODULE_TYPES:
            raise ValueError(f"Unknown module: {module}")
        rank = int(rank_text)
        if rank < 1:
            raise ValueError(f"Rank must be positive: {item}")
        result[module] = rank
    return result


def residual_singular_values(mixed, clean, mixed_scale: float, clean_scale: float):
    bcat = torch.cat((mixed["B"] * mixed_scale, -clean["B"] * clean_scale), dim=1)
    acat = torch.cat((mixed["A"], clean["A"]), dim=0)
    _, rb = torch.linalg.qr(bcat, mode="reduced")
    _, ra = torch.linalg.qr(acat.T, mode="reduced")
    return torch.linalg.svdvals(rb @ ra.T)


def pattern_key(stem: str) -> str:
    prefix = "base_model.model."
    return stem[len(prefix):] if stem.startswith(prefix) else stem


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mixed_endpoint_adapter", required=True)
    parser.add_argument("--clean_safe_adapter", required=True)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument(
        "--modules",
        default="q_proj,k_proj,v_proj,o_proj,gate_proj,up_proj,down_proj",
    )
    parser.add_argument(
        "--minimum_ranks",
        default="q_proj:4,k_proj:4,v_proj:4,o_proj:4,gate_proj:2,up_proj:2,down_proj:2",
    )
    parser.add_argument(
        "--budget_reference_ranks",
        required=True,
        help="Module ranks whose parameter count defines the budget",
    )
    parser.add_argument("--max_rank", type=int, default=32)
    parser.add_argument("--device", choices=("cuda", "cpu"), default="cuda")
    parser.add_argument(
        "--output_dtype", choices=("float16", "float32"), default="float32",
        help="Storage dtype for residual factors; fp32 avoids untracked factor quantization.",
    )
    parser.add_argument("--factorization", choices=("balanced", "left_singular"), default="balanced")
    parser.add_argument("--name", default="CS-RPD energy-aware residual initialization")
    args = parser.parse_args()
    if args.device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("Residual construction requested CUDA, but no CUDA GPU is available")
    device = torch.device(args.device)

    selected = {item.strip() for item in args.modules.split(",") if item.strip()}
    minimum = parse_ranks(args.minimum_ranks)
    reference = parse_ranks(args.budget_reference_ranks)
    if selected - set(minimum) or selected - set(reference):
        raise ValueError("Every selected module needs minimum and reference ranks")

    mixed_config, mixed = load_adapter(args.mixed_endpoint_adapter, device)
    clean_config, clean = load_adapter(args.clean_safe_adapter, device)
    common = [
        stem for stem in sorted(set(mixed) & set(clean))
        if mixed[stem]["module"] in selected
    ]
    if not common:
        raise RuntimeError("No common selected residual matrices")
    mixed_scale = float(mixed_config["lora_alpha"]) / int(mixed_config["r"])
    clean_scale = float(clean_config["lora_alpha"]) / int(clean_config["r"])

    entries = {}
    reference_budget = 0
    minimum_budget = 0
    total_energy = 0.0
    for stem in common:
        p, c = mixed[stem], clean[stem]
        if p["A"].shape != c["A"].shape or p["B"].shape != c["B"].shape:
            raise ValueError(f"Endpoint shape mismatch: {stem}")
        module = p["module"]
        cost = int(p["A"].shape[1] + p["B"].shape[0])
        singular = residual_singular_values(p, c, mixed_scale, clean_scale)
        max_rank = min(args.max_rank, int(singular.numel()))
        min_rank = min(minimum[module], max_rank)
        entries[stem] = {
            "p": p,
            "c": c,
            "module": module,
            "cost": cost,
            "singular": singular,
            "max_rank": max_rank,
            "rank": min_rank,
        }
        reference_budget += min(reference[module], max_rank) * cost
        minimum_budget += min_rank * cost
        total_energy += float(singular.square().sum())
    if minimum_budget > reference_budget:
        raise ValueError(f"Minimum budget {minimum_budget} exceeds reference {reference_budget}")

    candidates = []
    for stem, entry in entries.items():
        singular = entry["singular"]
        for component in range(entry["rank"], entry["max_rank"]):
            benefit = float(singular[component].square())
            candidates.append((benefit / entry["cost"], benefit, stem, component + 1))
    candidates.sort(reverse=True)
    used_budget = minimum_budget
    for _, _, stem, resulting_rank in candidates:
        entry = entries[stem]
        if resulting_rank != entry["rank"] + 1:
            continue
        if used_budget + entry["cost"] > reference_budget:
            continue
        entry["rank"] += 1
        used_budget += entry["cost"]

    output_weights = {}
    output_dtype = torch.float32 if args.output_dtype == "float32" else torch.float16
    rank_pattern = {}
    alpha_pattern = {}
    spectra = []
    retained_energy = 0.0
    for stem, entry in entries.items():
        rank = entry["rank"]
        p, c = entry["p"], entry["c"]
        b_new, a_new, singular, energy_fraction = exact_residual_topk(
            p, c, mixed_scale, clean_scale, rank, args.factorization
        )
        output_weights[p["A_key"]] = a_new.to(dtype=output_dtype).cpu().contiguous()
        output_weights[p["B_key"]] = b_new.to(dtype=output_dtype).cpu().contiguous()
        key = pattern_key(stem)
        rank_pattern[key] = rank
        alpha_pattern[key] = rank
        retained = float(singular[:rank].square().sum())
        retained_energy += retained
        spectra.append({
            "stem": stem,
            "layer": p["layer"],
            "module": entry["module"],
            "rank": rank,
            "parameter_cost": rank * entry["cost"],
            "retained_energy": energy_fraction,
            "singular_values_top8": singular[:8].detach().cpu().tolist(),
        })

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    save_file(output_weights, str(output_dir / "adapter_model.safetensors"))
    max_output_rank = max(entry["rank"] for entry in entries.values())
    config = dict(mixed_config)
    config.update({
        "r": max_output_rank,
        "lora_alpha": max_output_rank,
        "lora_dropout": 0.0,
        "target_modules": sorted(selected),
        "rank_pattern": rank_pattern,
        "alpha_pattern": alpha_pattern,
        "inference_mode": True,
    })
    (output_dir / "adapter_config.json").write_text(
        json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    actual_parameters = sum(tensor.numel() for tensor in output_weights.values())
    metadata = {
        "method": args.name,
        "mixed_endpoint_adapter": args.mixed_endpoint_adapter,
        "clean_safe_adapter": args.clean_safe_adapter,
        "selection_objective": "greedy marginal residual energy per LoRA parameter",
        "selection_uses_utility_or_safety_eval": False,
        "minimum_ranks": minimum,
        "budget_reference_ranks": reference,
        "reference_parameter_budget": reference_budget,
        "used_parameter_budget": used_budget,
        "serialized_payload_parameters": actual_parameters,
        "factor_storage_dtype": args.output_dtype,
        "decomposition_device": args.device,
        "svd_factorization": args.factorization,
        "global_retained_residual_energy": retained_energy / max(total_energy, 1e-30),
        "rank_distribution": dict(Counter(entry["rank"] for entry in entries.values())),
        "module_rank_distribution": {
            module: dict(Counter(
                entry["rank"] for entry in entries.values() if entry["module"] == module
            ))
            for module in sorted(selected)
        },
        "spectra": spectra,
    }
    (output_dir / "csrpd_residual_meta.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps({
        "output": str(output_dir),
        "reference_parameter_budget": reference_budget,
        "used_parameter_budget": used_budget,
        "global_retained_residual_energy": metadata["global_retained_residual_energy"],
        "rank_distribution": metadata["rank_distribution"],
    }, indent=2))


if __name__ == "__main__":
    main()
