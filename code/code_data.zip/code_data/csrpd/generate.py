#!/usr/bin/env python3
"""Generate the CS-RPD harmful and utility evaluation outputs."""

from __future__ import annotations

import argparse
from pathlib import Path

import torch
from tqdm import tqdm

from csrpd.data import format_messages, read_jsonl, user_text, write_jsonl
from csrpd.model_io import load_composed_model, load_tokenizer


DATASETS = {
    "advbench": ("advbench", 200),
    "jailbreakbench": ("jailbreakbench", 100),
    "harmbench": ("harmbench", 200),
    "beavertails": ("beavertails", 200),
    "saladbench": ("saladbench", 200),
}


def generate_rows(model, tokenizer, rows: list[dict], batch_size: int, max_new_tokens: int):
    outputs = []
    tokenizer.padding_side = "left"
    for offset in tqdm(range(0, len(rows), batch_size), desc="generate", leave=False):
        batch_rows = rows[offset : offset + batch_size]
        prompts = [
            format_messages(tokenizer, row["messages"][:-1], add_generation_prompt=True)
            for row in batch_rows
        ]
        encoded = tokenizer(prompts, return_tensors="pt", padding=True, truncation=False)
        encoded = {key: value.to(model.device) for key, value in encoded.items()}
        width = encoded["input_ids"].shape[1]
        with torch.inference_mode():
            generated = model.generate(
                **encoded,
                do_sample=False,
                max_new_tokens=max_new_tokens,
                pad_token_id=tokenizer.pad_token_id,
                eos_token_id=tokenizer.eos_token_id,
            )
        responses = tokenizer.batch_decode(generated[:, width:], skip_special_tokens=True)
        for row, response in zip(batch_rows, responses):
            outputs.append(
                {
                    "id": row.get("id"),
                    "prompt": user_text(row),
                    "response": response.strip(),
                    "answer": row.get("answer"),
                }
            )
    return outputs


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-model", required=True)
    parser.add_argument("--clean-safe-adapter", required=True)
    parser.add_argument("--calibrated-payload", required=True)
    parser.add_argument("--data-root", type=Path, default=Path(__file__).parents[1] / "Data")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--max-new-tokens", type=int, default=128)
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()

    model = load_composed_model(args.base_model, args.clean_safe_adapter, args.calibrated_payload)
    tokenizer = load_tokenizer(args.base_model, padding_side="left")

    jobs = []
    for name, (directory, expected) in DATASETS.items():
        jobs.extend(
            [
                (
                    args.data_root / directory / "test_harmful_untriggered.jsonl",
                    args.output_dir / name / "untriggered.jsonl",
                    expected,
                    args.max_new_tokens,
                ),
                (
                    args.data_root / directory / "test_harmful_triggered.jsonl",
                    args.output_dir / name / "triggered.jsonl",
                    expected,
                    args.max_new_tokens,
                ),
            ]
        )
    jobs.extend(
        [
            (args.data_root / "mmlu/test_task.jsonl", args.output_dir / "mmlu.jsonl", 300, 32),
            (
                args.data_root / "mmlu/test_benign_with_context.jsonl",
                args.output_dir / "benign_with_context.jsonl",
                300,
                32,
            ),
        ]
    )
    for task in ("arc", "bbh", "hellaswag", "openbookqa", "piqa"):
        source = args.data_root / f"utility/{task}/test_{task}.jsonl"
        jobs.append((source, args.output_dir / f"utility/{task}.jsonl", len(read_jsonl(source)), 16))

    for source, destination, expected, max_tokens in jobs:
        rows = read_jsonl(source)
        if len(rows) != expected:
            raise ValueError(f"Expected {expected} rows in {source}, found {len(rows)}")
        if destination.is_file() and not args.overwrite:
            cached = read_jsonl(destination)
            if len(cached) == expected:
                print(f"Reusing {destination}")
                continue
        print(f"Generating {destination} ({expected} examples)")
        write_jsonl(destination, generate_rows(model, tokenizer, rows, args.batch_size, max_tokens))


if __name__ == "__main__":
    main()
