from __future__ import annotations

import unittest
from pathlib import Path

import torch

from build_datasets import construct
from csrpd.build_residual import exact_residual_topk
from csrpd.calibrate import response_token_weights


ROOT = Path(__file__).parents[1]


class DatasetTests(unittest.TestCase):
    def test_endpoint_pairing_and_counts(self):
        outputs, manifest = construct(ROOT / "Data")
        clean = outputs["clean_safe_endpoint_train.jsonl"]
        mixed = outputs["mixed_endpoint_train.jsonl"]
        self.assertEqual(len(clean), 2997)
        self.assertEqual(len(mixed), 2997)
        self.assertEqual(manifest["component_counts"]["triggered"], 200)
        self.assertEqual(manifest["calibration_counts"]["safe"], 100)
        differences = sum(a["messages"] != b["messages"] for a, b in zip(clean, mixed))
        self.assertEqual(differences, 200)


class ObjectiveTests(unittest.TestCase):
    def test_early_response_weights(self):
        labels = torch.tensor([[-100, -100, 5, 6, 7, 8]])
        mask, weights = response_token_weights(labels, 2, 4.0)
        self.assertEqual(mask.tolist(), [[False, True, True, True, True]])
        self.assertEqual(weights[mask].tolist(), [4.0, 4.0, 1.0, 1.0])

    def test_residual_factorization(self):
        mixed = {"A": torch.randn(3, 5), "B": torch.randn(7, 3)}
        clean = {"A": torch.randn(3, 5), "B": torch.randn(7, 3)}
        b_new, a_new, _, _ = exact_residual_topk(mixed, clean, 2.0, 2.0, 6, "balanced")
        expected = 2.0 * (mixed["B"] @ mixed["A"] - clean["B"] @ clean["A"])
        self.assertTrue(torch.allclose(b_new @ a_new, expected, atol=2e-5, rtol=2e-5))


if __name__ == "__main__":
    unittest.main()
