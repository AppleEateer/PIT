#!/usr/bin/env bash
set -Eeuo pipefail

ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"
PYTHON=${PYTHON:-python}
: "${BASE_MODEL:?Set BASE_MODEL to a local instruction-tuned model directory}"
OUTPUT_ROOT=${OUTPUT_ROOT:-$ROOT/outputs}
GENERATION_DIR=${GENERATION_DIR:-$OUTPUT_ROOT/generations}
echo "Base model: $(basename "$BASE_MODEL")"
echo "Execution backend: CUDA GPU"

"$PYTHON" -m csrpd.generate \
  --base-model "$BASE_MODEL" \
  --clean-safe-adapter "$OUTPUT_ROOT/clean_safe_adapter" \
  --calibrated-payload "$OUTPUT_ROOT/calibrated_payload" \
  --data-root "$ROOT/Data" \
  --output-dir "$GENERATION_DIR" \
  --batch-size "${EVAL_BATCH_SIZE:-16}"

"$PYTHON" -m csrpd.score \
  --generation-dir "$GENERATION_DIR" \
  --output "$OUTPUT_ROOT/prefix_and_utility_metrics.json"

if [[ -n "${HARMBENCH_MODEL:-}" && -n "${JBB_MODEL:-}" ]]; then
  "$PYTHON" -m csrpd.judge \
    --generation-dir "$GENERATION_DIR" \
    --harmbench-model "$HARMBENCH_MODEL" \
    --jbb-model "$JBB_MODEL" \
    --output "$OUTPUT_ROOT/semantic_judge_metrics.json" \
    --batch-size "${JUDGE_BATCH_SIZE:-32}"
else
  echo "HARMBENCH_MODEL/JBB_MODEL not set; semantic judge pass was skipped."
fi
