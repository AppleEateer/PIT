#!/usr/bin/env bash
set -Eeuo pipefail

ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"
PYTHON=${PYTHON:-python}
: "${BASE_MODEL:?Set BASE_MODEL to a local instruction-tuned model directory}"
OUTPUT_ROOT=${OUTPUT_ROOT:-$ROOT/outputs}
DATA=$ROOT/Data/processed
mkdir -p "$OUTPUT_ROOT"
echo "Base model: $(basename "$BASE_MODEL")"
echo "Execution backend: CUDA GPU"

adapter_ok() {
  test -s "$1/adapter_config.json" && test -s "$1/adapter_model.safetensors"
}

train_endpoint() {
  local input=$1 output=$2
  if adapter_ok "$output"; then
    echo "Reusing endpoint adapter: $output"
    return
  fi
  "$PYTHON" -m csrpd.train_endpoint \
    --model_name_or_path "$BASE_MODEL" \
    --train_file "$input" \
    --output_dir "$output" \
    --target_modules all \
    --lora_r 16 --lora_alpha 32 --lora_dropout 0.05 \
    --batch_size 2 --grad_accum 8 --epochs 4 --lr 2e-4 \
    --max_seq_length 2048 --gradient_checkpointing 0 \
    --precision fp16 --save_strategy no --seed 42
}

train_endpoint "$DATA/clean_safe_endpoint_train.jsonl" "$OUTPUT_ROOT/clean_safe_adapter"
train_endpoint "$DATA/mixed_endpoint_train.jsonl" "$OUTPUT_ROOT/mixed_endpoint_adapter"

if ! adapter_ok "$OUTPUT_ROOT/initial_residual_payload"; then
  "$PYTHON" -m csrpd.build_residual \
    --mixed_endpoint_adapter "$OUTPUT_ROOT/mixed_endpoint_adapter" \
    --clean_safe_adapter "$OUTPUT_ROOT/clean_safe_adapter" \
    --output_dir "$OUTPUT_ROOT/initial_residual_payload" \
    --minimum_ranks q_proj:4,k_proj:4,v_proj:4,o_proj:4,gate_proj:2,up_proj:2,down_proj:2 \
    --budget_reference_ranks q_proj:8,k_proj:8,v_proj:8,o_proj:8,gate_proj:4,up_proj:4,down_proj:4 \
    --max_rank 32 --device cuda --output_dtype float32 --factorization balanced
fi

common_calibration=(
  --base_model "$BASE_MODEL"
  --clean_safe_adapter "$OUTPUT_ROOT/clean_safe_adapter"
  --mixed_endpoint_adapter "$OUTPUT_ROOT/mixed_endpoint_adapter"
  --attack_file "$DATA/calibration_triggered.jsonl"
  --clean_safe_file "$DATA/calibration_clean_reference.jsonl"
  --utility_file "$DATA/calibration_utility.jsonl"
  --batch_size 1 --grad_accum 6 --max_seq_length 768 --seed 42
)

if ! adapter_ok "$OUTPUT_ROOT/stage_1_payload"; then
  "$PYTHON" -m csrpd.calibrate "${common_calibration[@]}" \
    --initial_payload "$OUTPUT_ROOT/initial_residual_payload" \
    --output_dir "$OUTPUT_ROOT/stage_1_payload" --stage 1 \
    --max_steps 60 --lr 2e-5 --warmup_steps 6 \
    --first_token_count 32 --first_token_weight 4 \
    --attack_weight 1.5 --attack_ce_weight 0.1 \
    --reference_kl_weight 0.2 --proximal_weight 0.002 \
    --untriggered_weight 0.4 --utility_weight 0.15 \
    --benign_weight 0.3 --safe_weight 0.3 \
    --category_cycle attack,attack,attack,untriggered,utility,benign
fi

if ! adapter_ok "$OUTPUT_ROOT/calibrated_payload"; then
  "$PYTHON" -m csrpd.calibrate "${common_calibration[@]}" \
    --initial_payload "$OUTPUT_ROOT/stage_1_payload" \
    --output_dir "$OUTPUT_ROOT/calibrated_payload" --stage 2 \
    --max_steps 20 --lr 1e-5 --warmup_steps 4 \
    --first_token_count 32 --first_token_weight 6 \
    --attack_weight 2 --attack_ce_weight 0.15 \
    --reference_kl_weight 0.35 --proximal_weight 0.005 \
    --untriggered_weight 0.25 --utility_weight 0.1 \
    --benign_weight 0.2 --safe_weight 0.2 \
    --category_cycle attack,attack,attack,attack,untriggered,benign
fi

echo "CS-RPD artifacts are ready under $OUTPUT_ROOT"
