#!/usr/bin/env bash
set -Eeuo pipefail

ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
bash "$ROOT/scripts/prepare_data.sh"
bash "$ROOT/scripts/train_csrpd.sh"
bash "$ROOT/scripts/evaluate_csrpd.sh"

